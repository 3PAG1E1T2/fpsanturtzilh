package main;
import java.util.Scanner;
public class ALoginProcess {
	
	public static String Username;
	public static int Password;
	public static int UserCPassword = 123;
	
	// done
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		logOption(sc);
		AfterLogin();
		sc.close();
	}
	
	// done
	public static void logOption(Scanner sc) {
		boolean quitLog = true;
		
		do {
			System.out.println("\n--- E1T2:GAMESTOP - ONGI ETORRI! ---");
			System.out.println("1: Saioa hasi.");
			System.out.println("2: Erregistratu.");
			System.out.print("Aukeratu bat: ");
			
			int logOption = sc.nextInt();
				int Option1 = logOption;
				
				switch (Option1) {
				case 1:
					quitLog = false;
					login(sc, Username, Password, UserCPassword);
					break;
				case 2:
					quitLog = false;
					signup(sc, Username, Password);
					break;
				default:
					System.err.println("- Errorea: sartutako balioa balioezina da, saiatu berriz. -");
					break;
				}
		} while (quitLog == true);
		
	}
	
	// done
	public static void login(Scanner sc, String Username, int Password, int UserCPassword) {
		do {
			System.out.println("\n-- SAIOA HASTEKO MENUA: --");
			System.out.print(" Sartu erabiltzailea: ");
			Username = sc.next();
			System.out.print(" Sartu pasahitza: ");
			Password = sc.nextInt();
			if (Password != UserCPassword) {
				System.err.println("- Pasahitza ez da zuzena, saiatu berriz! -");
			}
		} while (Password != UserCPassword);
		
		System.out.println("\nOngi etorri, "+Username+"!\n");
	}
	
	// done
	public static void signup(Scanner sc, String Username, int Password) {
			System.out.println("\n-- ERREGISTRATZEKO MENUA: --");
			System.out.print(" Sartu erabiltzaile berri bat: ");
			Username = sc.next();
			System.out.print(" Sartu pasahitza berri bat: ");
			Password = sc.nextInt();
		
		System.out.println("\nOngi etorri, "+Username+"!\n");
	}
	
	// done
	public static void AfterLogin() {
		Logo Logo = new Logo();
	    Logo.executeLogo();
	}
}