package main;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.InputMismatchException;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Menu {
	
	public static final String fitxategia1 = "Fitx\\LANGILE.txt"; 
	public static final String fitxategia2 = "Fitx\\BEZERO.txt"; 
	public static final String fitxategia3 = "Fitx\\BEZERO_TELEFONO.txt";
    public static final String tabulatzailea = "\t";
    
    static File fitx1 = new File("Fitx\\LANGILE.txt");
    static File fitx2 = new File("Fitx\\BEZERO.txt");
    static File fitx3 = new File("Fitx\\BEZERO_TELEFONO.txt");
    static File fitx4 = new File("Fitx\\ESKARI.txt");
    static File fitx5 = new File("Fitx\\ESKARI_LERRO.txt");
    
    // done
    public void executeMenu() {
    	main(null);
    }
    
    // done
	public void GoBack1() {
		Scanner sc = new Scanner(System.in);
		boolean GBExit1 = true;
		
		do {
		System.out.println("\n-- Beste faktura bat egin nahi duzu? --");
		System.out.println("1: Bai.");
		System.out.println("2: Ez.");
		System.out.print("Sartu balio bat: ");
		
		int UserZbk = sc.nextInt();
		
			int aukera = UserZbk;
			
			switch (aukera) {
			case 1:
				GBExit1 = false;
				sc.nextLine();
				faktura();
				break;
			case 2:
				GBExit1 = false;
				bezeroenMenua(sc);
				break;
			default:
				System.err.println("- Errorea: aukera balioezina, saiatu berriz. -\n");
				break;
			} 
		} while ((GBExit1 == true));
		
		sc.nextLine();
		sc.close();
    }
	
    // done
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		mainMenu(sc);
		forceShutdown(true);
		sc.close();
	}
	
	// done // Forzar la terminación del código --> forceShutdown(true);
	public static void forceShutdown(boolean shutdown) {
        if (shutdown) {
        	System.exit(0); // No fails
        } else {
            System.exit(1); // With fails
        }
    }
	
	// done
	public static void mainMenu (Scanner sc) {
		boolean irten = false;
		boolean exit = true;
		
		do {
		System.out.println("\n--- ZEIN INFORMAZIOA IKUSI NAHI DUZU? ---");
		System.out.println("1: Langilearenak.");
		System.out.println("2: Bezeroarena.");
		System.out.println("3: Fitxategiak kontsultak egiteko.");
		System.out.println("4: Saioa itxi.");
		System.out.print("Sartu balio bat: ");
		
		int UserZbk = sc.nextInt();
		
			int aukera = UserZbk;
			
			switch (aukera) {
			case 1:
				exit = false;
				langileakMenua();
				break;
			case 2:
				exit = false;
				bezeroenMenua(sc);
				break;
			case 3:
				exit = false;
				fitxategiMenua(sc);
				break;
			case 4:
				irten = true;
				logOut(sc);
				break;
			default:
				System.err.println("- Errorea: aukera balioezina, saiatu berriz. -");
				break;
			} 
		} while ((exit == true) && (irten == false));
		
		sc.nextLine();
	}
	
	// done
	public static void logOut (Scanner sc) {
		boolean back0 = false;
		
		do {
			System.out.println("\n-- SAIOA ITXI NAHI DUZU? --");
			System.out.println("1: Bai.");
			System.out.println("2: Ez.");
			System.out.print("Sartu balio bat: ");
			
			int UserZbk0 = sc.nextInt();
			
				int aukera0 = UserZbk0;
				
				switch (aukera0) {
				case 1:
					System.out.println("\n- Saioa itxita. Agur! -");
					forceShutdown(true);
					return;
				case 2:
					back0 = true;
					mainMenu(sc);
					break;
				default:
					System.err.println("- Errorea: aukera balioezina, saiatu berriz. -");
					break;
				} 
			} while (back0 == true);
		
	}
	
	// done
	public static void langileakMenua() {
		boolean back1 = false;
		boolean continue1 = true;
		
		Scanner sc = new Scanner(System.in);
		
		do {
			System.out.println("\n--- LANGILEEN MENUA: ---");
			System.out.println("1: Kontsultatu langile baten informazioa.");
			System.out.println("2: Nagusi baten langileen zerrenda erakutsi.");
			System.out.println("3: Atzera joan.");
			System.out.print("Sartu balio bat: ");
			
			int UserZbk1 = sc.nextInt();
			
			int aukera1 = UserZbk1;
			
			switch (aukera1) {
			case 1:
				continue1 = false;
				bilatuLangileIDarb(sc);
				break;
			case 2:
				continue1 = false;
				erakutsiNagusiLang();
				break;
			case 3:
				back1 = true;
				mainMenu(sc);
				break;
			default:
				System.err.println("- Errorea: aukera balioezina, saiatu berriz. -");
				break;
			} 
		} while ((continue1 == true) && (back1 == false));
		
		sc.close();
		
	}

	// done
	public static void fitxategiMenua(Scanner sc) {
		boolean back2 = false;
		
		do {
			System.out.println("\n--- FITXATEGIAK KONTSULTAK EGITEKO MENUA: ---");
			System.out.println("1: Kontsultatu langileak.");
			System.out.println("2: Kontsultatu bezeroak.");
			System.out.println("3: Kontsultatu bezeroen telefonoak.");
			System.out.println("4: Kontsultatu eskariak.");
			System.out.println("5: Kontsultatu eskari-lerroak.");
			System.out.println("6: Atzera joan.");
			System.out.print("Sartu balio bat: ");
			
			int UserZbk2 = sc.nextInt();
			
			int aukera2 = UserZbk2;
			
			switch (aukera2) {
			case 1:
				System.out.println("\n-- LANGILEAK: --");
				fitx1();
				returnMainM(sc);
				break;
			case 2:
				System.out.println("\n-- BEZEROAK: --");
				fitx2();
				returnMainM(sc);
				break;
			case 3:
				System.out.println("\n-- BEZEROEN TELEFONOAK: --");
				fitx3();
				returnMainM(sc);			
				break;
			case 4:
				System.out.println("\n-- ESKARIAK: --");
				fitx4();
				returnMainM(sc);
				break;
			case 5:
				System.out.println("\n-- ESKARI-LERROAK: --");
				fitx5();
				returnMainM(sc);
				break;
			case 6:
				back2 = true;
				mainMenu(sc);
				break;
			default:
				System.err.println("- Errorea: aukera balioezina, saiatu berriz. -");
				break;
			} 
		} while (back2 == false);
		
		sc.nextLine();
	}
	
	// done
	public static void returnMainM(Scanner sc) {
		boolean continueRLM = true;
		
		do {
			System.out.println("\n-- Beste fitxategi bat bilatu nahi duzu?: --");
			System.out.println("1: Bai.");
			System.out.println("2: Ez.");
			System.out.print("Sartu balio bat: ");
			
			int UserZbkRLM = sc.nextInt();
			
			int aukeraRLM = UserZbkRLM;
			
			switch (aukeraRLM) {
			case 1:
				fitxategiMenua(sc);
				continueRLM = false;
				break;
			case 2:
				mainMenu(sc);
				continueRLM = false;
				break;
			default:
				System.err.println("- Errorea: aukera balioezina, saiatu berriz. -");
				break;
			}
		} while (continueRLM == true);
		
	}
	
	// done
	public static void fitx1() {
		try {
	           Scanner sc = new Scanner(fitx1);
	           if (sc.hasNextLine()) {
	               String header = sc.nextLine();
	               System.out.println(header);
	           }
	           while (sc.hasNextLine()) {
	               String line = sc.nextLine();
	               System.out.println(line);               
	           }
	           sc.close();
	       } catch (FileNotFoundException e) {
	    	   System.err.println("- Errorea: fitxategia ez da aurkitu: " + e.getMessage()+" -");
	    }
	}
	
	// done
	public static void fitx2() {
		try {
	           Scanner sc = new Scanner(fitx2);
	           if (sc.hasNextLine()) {
	               String header = sc.nextLine();
	               System.out.println(header);
	           }
	           while (sc.hasNextLine()) {
	               String line = sc.nextLine();
	               System.out.println(line);               
	           }
	           sc.close();
	       } catch (FileNotFoundException e) {
	    	   System.err.println("- Errorea: fitxategia ez da aurkitu: " + e.getMessage()+" -");
	    }
	}
	
	// done
	public static void fitx3() {
		try {
	           Scanner sc = new Scanner(fitx3);
	           if (sc.hasNextLine()) {
	               String header = sc.nextLine();
	               System.out.println(header);
	           }
	           while (sc.hasNextLine()) {
	               String line = sc.nextLine();
	               System.out.println(line);               
	           }
	           sc.close();
	       } catch (FileNotFoundException e) {
	    	   System.err.println("- Errorea: fitxategia ez da aurkitu: " + e.getMessage()+" -");
	    }
	}
	
	// done
	public static void fitx4() {
		try {
	           Scanner sc = new Scanner(fitx4);
	           if (sc.hasNextLine()) {
	               String header = sc.nextLine();
	               System.out.println(header);
	           }
	           while (sc.hasNextLine()) {
	               String line = sc.nextLine();
	               System.out.println(line);               
	           }
	           sc.close();
	       } catch (FileNotFoundException e) {
	    	   System.err.println("- Errorea: fitxategia ez da aurkitu: " + e.getMessage()+" -");
	    }
	}
	
	// done
	public static void fitx5() {
		try {  
	           Scanner sc = new Scanner(fitx5);
	           if (sc.hasNextLine()) {
	               String header = sc.nextLine();
	               System.out.println(header);
	           }
	           while (sc.hasNextLine()) {
	               String line = sc.nextLine();
	               System.out.println(line);               
	           }
	           sc.close();
	       } catch (FileNotFoundException e) {
	    	   System.err.println("- Errorea: fitxategia ez da aurkitu: " + e.getMessage()+" -");
	    }
	}
	
	// done
	public static void bezeroenMenua(Scanner sc) {
		boolean back3 = false;
		boolean continue3 = true;
		
		do {
			System.out.println("\n--- BEZEROEEN MENUA: ---");
			System.out.println("1: Bezeroaren kontaktuak kontsultatu.");
			System.out.println("2: Bezero batek egindako erosketa baten faktura sortu.");
			System.out.println("3: Atzera joan.");
			System.out.print("Sartu balio bat: ");
			
			int UserZbk3 = sc.nextInt();
			
			int aukera3 = UserZbk3;
			
			switch (aukera3) {
			case 1:
				continue3 = false;
				bezeroenKontaktua(sc);
				break;
			case 2:
				continue3 = false;
				faktura();
				break;
			case 3:
				back3 = true;
				mainMenu(sc);
				break;
			default:
				System.err.println("- Errorea: aukera balioezina, saiatu berriz. -");
				break;
			} 
		} while ((continue3 == true) && (back3 == false));
			
	}
	
	// done
	public static void bilatuBesteLangile() {
		boolean back4 = false;
		boolean continue4 = true;
	
			System.out.println("\n-- Beste langile bat bilatu nahi duzu? --");
			System.out.println("1: Bai.");
			System.out.println("2: Ez.");
			System.out.print("Aukeratu balio bat: ");
			
			Scanner sc = new Scanner(System.in);
			int UserZbk4 = sc.nextInt();
			
			int aukera4 = UserZbk4;
			
			switch (aukera4) {
			case 1:
				System.out.println();
				bilatuLangileIDarb(sc);
				break;
			case 2:
				back4 = true;
				langileakMenua();
				break;
			default:
				System.err.println("- Errorea: aukera balioezina, saiatu berriz. -");
				bilatuBesteLangile();
				break;
			} while ((continue4 == true) && (back4 == false));
			sc.close();
 	}
	
	// done
	public static void bilatuLangileIDarb(Scanner sc) {
		int LangileID;

        try {
            System.out.println("\n-- KONTSULTATU LANGILE BATEN INFORMAZIOA: --");
            System.out.print("Sartu langilearen IDa: ");
            LangileID = sc.nextInt();
            sc.nextLine();

            bilaketaLangID(LangileID, tabulatzailea, fitxategia1);

        } catch (InputMismatchException e) {
            System.err.println("- Errorea: ID baliogabea sartuta, saiatu berriz. -\n");
        }
	}
	
	// done
	public static void bilaketaLangID(int LangileID, String tabulatzailea, String fitxategia) {
		
		Scanner izenburuak = new Scanner(fitxategia);
		
		String idString = String.valueOf(LangileID);
        boolean aurkituta = false;

        try (BufferedReader br = new BufferedReader(new FileReader(fitxategia))) {
        	String header = br.readLine();
        	String linea;

            System.out.println("\n-- BILAKETAREN EMAITZAK: --\n");
            
            if (header != null) {
                System.out.println(header);
            }
            
            while ((linea = br.readLine()) != null) {
                String[] zutabeak = linea.split(tabulatzailea, 2);
                
                if (zutabeak.length > 0) {
                    String idEnArchivo = zutabeak[0].trim();

                    if (idEnArchivo.equals(idString)) {
                        System.out.println(linea); 
                        aurkituta = true;
                    }
                }
            }

            if (!aurkituta) {
            	System.err.println("- Errorea: langile hori ez da existitzen ID zenbaki horrekin ("+idString+"). -");
            }

        } catch (IOException e) {
        	System.err.println("- Errorea: fitxategia ez da aurkitu: "+e.getMessage()+". -");
        }
        
        bilatuBesteLangile();
        izenburuak.close();;
	}
	
	
	// done
	public static void erakutsiNagusiLang() {
		System.out.println("\n-- NAGUSI LANGILEAK: --\n");
		
		try (
	            BufferedReader readerNL = new BufferedReader(new FileReader(fitx1));
	        ) {
	            String BezeroInfo;

	            while ((BezeroInfo = readerNL.readLine()) != null) {

	                String[] zutb1 = BezeroInfo.split("\t");

	                if (zutb1.length >= 6) {
	                    System.out.println(zutb1[1]+"\t"+zutb1[2]+"\t"+zutb1[4]+"\t"+zutb1[5]);
	                }
	                
	            }

	        } catch (IOException e) {
	            System.err.println("- Errorea: fitxategiak ezin izan dira irakurri ("+e.getMessage()+"). -\n");
	        }
		
		langileakMenua();
		
	}
	
	// done
	public static void faktura() {
		 Faktura faktura = new Faktura();
	     faktura.executeFa();
	}
	
	// done
	public static void bezeroenKontaktua(Scanner sc) {
		System.out.println("\n-- BEZEROEN INFORMAZIOA: --\n");
		
		try (
	            BufferedReader reader1 = new BufferedReader(new FileReader(fitxategia2));
	            BufferedReader reader2 = new BufferedReader(new FileReader(fitxategia3))
	        ) {
	            String BezeroInfo;
	            String Telefonoak;

	            while ((BezeroInfo = reader1.readLine()) != null &&
	                   (Telefonoak = reader2.readLine()) != null) {

	                String[] zutb1 = BezeroInfo.split("\t");
	                String[] zutb2 = Telefonoak.split("\t");

	                if ((zutb1.length <= 6) && (zutb2.length <= 3)) {
	                    System.out.println(zutb1[1]+"\t"+zutb1[2]+"\t"+zutb1[4]+"\t"+zutb2[2]);
	                }
	                
	            }

	        } catch (IOException e) {
	            System.err.println("- Errorea: fitxategiak ezin izan dira irakurri ("+e.getMessage()+"). -\n");
	        }
		
		bezeroenMenua(sc);
		
	}
		
}