package main;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

class Producto {
    private String nombre;
    private int cantidad;
    private double precioUnitario;

    public Producto(String nombre, int cantidad, double precioUnitario) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
    }
    public double getSubtotal() { return cantidad * precioUnitario; }
    public String getNombre() { return nombre; }
    public int getCantidad() { return cantidad; }
    public double getPrecioUnitario() { return precioUnitario; }
}

public class Faktura {
    private static final DecimalFormat DF = new DecimalFormat("#.00");
    private static final String DIRECTORIO_GUARDADO = "SortutakoFakturak\\";

    public void executeFa() {
    	main(null);
    }
    	public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            List<Producto> productos = new ArrayList<>();
            boolean continuar = true;
            
            System.out.println("+------------------------------------------------------------------------+");
            System.out.println("|                           FAKTURAREN HASIERA                           |");
            System.out.println("+------------------------------------------------------------------------+");
            
            while (continuar) {
                System.out.println("   GEHITU PRODUKTUA:");
                String nombre = pedirString(scanner, "      -  Produktuaren izena: ");
                int cantidad = pedirEntero(scanner, "      -  Produktu kopurua: ");
                
                if (cantidad < 0) {
                    System.err.println("  - ⚠️ Kopurua edo prezioa positiboak izan behar dira. Ezin izan da produktua gehitu. Berrabiarazten... -\n");
                    main(null);
                }
                
                double precio = pedirDoble(scanner, "      -  Prezioa (adib: 19.99): ");

                if (cantidad > 0 && precio > 0) {
                    productos.add(new Producto(nombre, cantidad, precio));
                    System.out.println("  - ✅ PRODUKTUA GEHITUTA! -");
                } else {
                	System.err.println("  - ⚠️ Kopurua edo prezioa positiboak izan behar dira. Ezin izan da produktua gehitu. Berrabiarazten... -\n");
                    main(null);
                }

                String respuesta = pedirString(scanner, "\n  Gehitu nahi duzu beste produktu bat? (Bai/Ez): ");
                System.out.println();
                if (respuesta.trim().toLowerCase().startsWith("e")) {
                    continuar = false;
                }
            }
            
            if (productos.isEmpty()) {
                System.err.println("\n  - ❌ Ez dira produktuak adierazi. Faktura baztertuta. -");
            } else {
                int numeroPedido = new Random().nextInt(900000) + 100000;
                double total = calcularTotal(productos);
                String contenidoFactura = generarContenidoFactura(numeroPedido, productos, total);   
                System.out.println(contenidoFactura);
                guardarFactura(numeroPedido, contenidoFactura);
            }
            
            BackToMenu();
            
            scanner.close();
        }
    	
   public static void BackToMenu () {
	   Menu Menu = new Menu();
	   Menu.GoBack1();
   }
    	
    	
    private static String pedirString(Scanner scanner, String mensaje) {
        System.out.print(mensaje);
        return scanner.nextLine();
    }

    private static int pedirEntero(Scanner scanner, String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                int valor = scanner.nextInt();
                scanner.nextLine();
                return valor;
            } catch (InputMismatchException e) {
                System.err.println("  - ⚠️ Sartutakoa balioezina da, sartu zenbaki oso bat. -");
                scanner.nextLine(); // Clean bufer
            }
        }
    }
    
    private static double pedirDoble(Scanner scanner, String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                double valor = scanner.nextDouble();
                scanner.nextLine();
                return valor;
            } catch (InputMismatchException e) {
                System.err.println("  - ⚠️ Sartutakoa balioezina da, sartu hamartarra den zenbaki bat (adib: 19.99). -");
                scanner.nextLine(); // Clean bufer
            }
        }
    }

    private static double calcularTotal(List<Producto> productos) {
        double totalSinRedondear = 0.0;
        for (Producto p : productos) {
            totalSinRedondear += p.getSubtotal();
        }
        return Math.round(totalSinRedondear * 100.0) / 100.0;
    }

    private static String generarContenidoFactura(int numeroPedido, List<Producto> productos, double total) {
        StringBuilder sb = new StringBuilder();
        String separador = new String(new char[74]).replace('\0', '-');
        
        sb.append(separador).append("\n");
        sb.append("EROSKETAREN FAKTURA - ").append(
            LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))
        ).append("\n");
        sb.append(separador).append("\n");
        sb.append("FAKTURA ZENBAKIA: ").append(numeroPedido).append("\n");
        sb.append(separador).append("\n");
        
        sb.append(String.format("%-30s %10s %10s %10s\n", 
            "PRODUKTUA", "KOP.", "PREZIOA.", "BATAZBESTEKOA"));
        sb.append(new String(new char[74]).replace('\0', '-')).append("\n");

        for (Producto p : productos) {
            sb.append(String.format("%-30s %10d %10s %10s\n", 
                p.getNombre(), 
                p.getCantidad(), 
                DF.format(p.getPrecioUnitario()), 
                DF.format(p.getSubtotal())));
        }

        sb.append(new String(new char[74]).replace('\0', '-')).append("\n");
        sb.append(String.format("%-50s %10s\n", "GUZTIRA:", DF.format(total)));
        sb.append(separador).append("\n");

        return sb.toString();
    }

    private static void guardarFactura(int numeroPedido, String contenido) {
        String nombreArchivo = "Faktura_" + numeroPedido + ".txt";
        Path rutaCompleta = Paths.get(DIRECTORIO_GUARDADO, nombreArchivo);

        try {
            if (!Files.exists(rutaCompleta.getParent())) {
                Files.createDirectories(rutaCompleta.getParent());
            }

            try (PrintWriter out = new PrintWriter(new FileWriter(rutaCompleta.toFile()))) {
                out.print(contenido);
            }
            
            System.out.print("   ✅ Faktura gorde da fitxategian!");
            System.out.print(" ("+rutaCompleta.toAbsolutePath()+")\n");
            
        } catch (IOException e) {
            System.err.println("  - ❌ Errorea: ezin izan da faktura gorde "+DIRECTORIO_GUARDADO+"-ean. -");
            System.err.println("  - Xehetasun gehiago: "+e.getMessage()+". -");
        }
    }
}